<?php
/**
 * Copyright (c) BoonEx Pty Limited - http://www.boonex.com/
 * CC-BY License - http://creativecommons.org/licenses/by/3.0/
 */

bx_import('BxDolConfig');

class BxAvaConfig extends BxDolConfig
{
    /**
     * Constructor
     */
    function __construct($aModule)
    {
        parent::__construct($aModule);
    }
}
