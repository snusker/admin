<?php

$site['ver'] = '7.4';
$site['build'] = '2';

