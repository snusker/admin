<?php

class Thing
{
    function __construct() {}
}
